// onSelect(info) -> setSelected(info); bottomSheetRef.current?.expand();
<Text style={styles.title}>{info.name}</Text>
<Text style={styles.section}>Aromas: {info.aromas.join(', ')}</Text>
<Text style={styles.section}>Effects: {info.effects.join(', ')}</Text>
<Text style={styles.sectionSmall}>Strains: {info.strains.join(', ')}</Text>
